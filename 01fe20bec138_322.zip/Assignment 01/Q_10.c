#include <stdio.h>
#define N 50
void readArray(int arr[N], int n);
void isPrime(int arr[N], int n);

void main()
{
    int n, arr[N];
    printf("Enter the number of inputs:");
    scanf("%d", &n);

    readArray(arr, n);
    isPrime(arr, n);
}

void readArray(int arr[50], int n)
{

    int i;
    printf("Enter the numbers:");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
}

void isPrime(int arr[50], int n)
{
    int i, j, count = 0, m;
    int prime=0;
    for (i = 0; i< n; j++)
    {
        m = arr[i];
        for (j = 1; j <= m; j++)
        {
            if (m % j == 0)
            {

                count++;
            }
            if(count==2)
            {
                prime+=1;
            }
        }
    }
    printf("\nThe total number of prime numbers are %d", prime);
}
