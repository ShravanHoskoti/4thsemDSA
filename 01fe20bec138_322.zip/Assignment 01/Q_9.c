#include<stdio.h>
#define N 50

void readArray(int arr[N],int n);
void Even(int arr[N],int n);
void Odd(int arr[N],int n);
void full(int arr[N],int n);

void main()
{
    int n,arr[N];
    printf("Enter the number of students writing Post Test:");
    scanf("%d",&n);
    readArray(arr,n);
    Even(arr,n);
    Odd(arr,n);
    full(arr,n);
}

void readArray(int arr[50], int n)
{

    int i;
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
}

void Even(int arr[50], int n)
{
    int i,count=0;
    for (i = 0; i < n; i++)
    {
        if(arr[i]%2==0)
        {
            count++;
        }
    }
    printf("The number of students who scored Even marks are %d",count);
}

void Odd(int arr[50], int n)
{
    int i,count=0;
    for (i = 0; i < n; i++)
    {
        if(arr[i]%2!=0)
        {
            count++;
        }
    }
    printf("\nThe number of students who scored  Odd marks are %d",count);

}

void full(int arr[N],int n)
{
     int i,count=0;
    for (i = 0; i < n; i++)
    {
        if(arr[i]==10)
        {
            printf("The Student who scored 10 marks is Roll number %d",i+1);
            count++;
        }

    }
    printf("\nThe number of students who scored 10 marks are %d",count);
}