#include<stdio.h>
#define N 50

void readArray(int arr[50],int n);
void Expenditure(int arr[50],int n);
void average(int arr[50],int n );

void main()
{
    int n,arr[N];
    printf("Enter the number of Months :");     // Enter the valve as 12 
    scanf("%d",&n);
    readArray(arr,n);
    Expenditure(arr,n);
    average(arr,n);
}

void readArray(int arr[50], int n)
{

    int i;
    printf("Enter the amount spent every month in Thousands:");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
}

void average(int arr[50], int n)
{
    int i,sum=0;
    int avg;
    for (i = 0; i < n; i++)
    {
        sum=sum+arr[i];

    }
    avg=sum/12;

    printf("\nThe average expenditure of the Family is %d",avg);
    
}

void Expenditure(int arr[50],int n)
{
    int i;
    for ( i = 0; i < n; i++)
    {
        if(arr[i]>arr[0])
        {
            arr[0]=arr[i];
        }
        
        
    }

    for ( i = 0; i <n ; i++)
    {
        if(arr[0]==arr[i])
        {
            printf("The month which the family spent more is %d",i);
        }
    }
    


    int j;
    for ( j = 0; j < n; i++)
    {
        if(arr[j]<arr[0])
        {
            arr[0]=arr[j];
        }
        
        
    }

    for ( j = 0; j <n ; i++)
    {
        if(arr[0]==arr[j])
        {
            printf("The month which the family spent less is %d",j);
        }
    }
    


     
    
}