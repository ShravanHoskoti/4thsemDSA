#include <stdio.h>
void readArray(int arr[50], int n);
void amount(int arr[50], int n);
void average(int arr[50], int n);

void main()
{
    int arr[50], n;
    printf("Enter the number of people:");
    scanf("%d", &n);

    readArray(arr, n);
    amount(arr, n);
    average(arr, n);
}

void readArray(int arr[50], int n)
{

    int i;
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
}

void amount(int arr[50], int n)
{
    int i;
    int count_1 = 0;
    int count_2 = 0;
    for (i = 0; i < n; i++)
    {
        if (arr[i] > 2.5)
        {
            count_1++;
        }
        else if (arr[i] > 0.5 && arr[i] <= 1.5)
        {
            count_2++;
            /* code */
        }
    }
    printf("The number of people who paid more than 2.5 L are :%d", count_1);
    printf("\nThe number of people who paid  between 50 T and 1.5 L are :%d", count_2);
}

void average(int arr[50], int n)
{
    int i;
    int sum = 0, avg;
    for (i = 0; i < n; i++)
    {
        sum = sum + arr[i];
        /* code */
    }
    avg = sum / i;

    printf("SUM=%d", sum);
    printf("\nAVERAGE=%d", avg);
}

// void displayArray(int arr[50], int n)
// {
//     int i;
//     for (i = 0; i < n; i++)
//     {
//         printf("%d\t", arr[i]);
//         /* code */
//     }
// }
