#include <stdio.h>
#define N 50

void readArray(int arr[N], int arr1[N], int n);
void swapArray(int arr[N], int arr1[N], int n);
void displayArray(int arr[N],int arr1[N],int n);

void main()
{
    int n, arr[N], arr1[N];
    printf("Enter the size of arrays:");
    scanf("%d", &n);
    readArray(arr, arr1, n);
    swapArray(arr, arr1, n);
    displayArray(arr[N],arr1[N],n);
}

void readArray(int arr[N], int arr1[N], int n)
{

    int i;
    printf("Enter the elements of array 1:");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    printf("\nEnter the elements of array 2:");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr1[i]);
    }
}

void swapArray(int arr[50], int arr1[N], int n)
{
    int i, arr2[N];
    for (i = 0; i < n; i++)
    {

        // write any swapping technique
        arr2[i] = arr[i];
        arr[i] = arr1[i];
        arr1[i] = arr2[i];
    }
}

void displayArray(int arr[N],int arr1[N],int n)
{
    int i;
    printf("\nThe Swapped Arrays are:");
    printf("\nArray 1");
    for ( i = 0; i < n; i++)
    {
        printf("%d",arr[i]);
    }

    printf("\n");
    printf("\nArray 2");

    for ( i = 0; i < n; i++)
    {
        printf("%d",arr1[i]);
    }
    
    
}