#include<stdio.h>
int main()
{
    int N,i;
    int bonus_1,bonus_2,bonus_3;

    int arr_1[100],arr_2[100],arr_3[100];
    int sal_1=10600,sal_2=21300,sal_3=32100;
    
    
    int experience;
    int count_1,count_2,count_3;
    printf("Enter the number of Employees:");
    scanf("%d",&N);

    for (i= 0; i < N; i++)
    {
        printf("Enter the experience of Employee:");
        scanf("%d",&experience);
        
        if(experience >=5 && experience <=7)
        {
             bonus_1=sal_1+1060;
             arr_1[i]=bonus_1;
             count_1+=1;
             
        }
        else if (experience >=8 && experience <=10 )
        {
            bonus_2=sal_2+2130;
            arr_2[i]=bonus_2;
            count_2+=1;
            /* code */
        }

        else{
            bonus_3=sal_3+32100;
            arr_3[i]=bonus_3;
            count_3+=1;
        }
        
        
        
    }

    printf("\n");
    printf("To display the salary of Employees with Age experience of 5-7 years:");
    printf("\n");
    for(i=0;i<count_1;i++){
        printf("%d",arr_1[i]);
    }
    
    printf("\n");
    printf("To display the salary of Employees with Age experience of 8-10 years:");
    printf("\n");
    for(i=0;i<count_2;i++){
        printf("%d",arr_2[i]);
    }

    printf("\n");
    printf("To display the salary of Employees with Age experience of 5-7 years:");
    printf("\n");
    for(i=0;i<count_3;i++){
        printf("%d",arr_3[i]);
    }
    
    
    
}