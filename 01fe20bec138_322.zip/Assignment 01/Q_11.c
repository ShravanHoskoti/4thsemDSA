#include<stdio.h>
#define N 50

void readArray(int arr[N],int n);
void Bill(int arr[N],int n);

void main()
{
    int n,arr[N];
    printf("Enter the number of Flats in Apartment:");
    scanf("%d",&n);
    readArray(arr,n);
    Bill(arr,n);

}
void readArray(int arr[50], int n)
{

    int i;
    printf("Enter the number of Units Consumed for Each Flat:");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
}

void Bill(int arr[50], int n)
{
    int i;
    int bill_1,bill_2,bill_3,bill_4;
    for (i = 0; i < n; i++)
    {
        if(arr[i]>0 && arr[i]<100){
            bill_1=1.5*arr[i];
            printf("The bill paid by %d flat  is %d",i+1,bill_1);
        }
        

        else if(arr[i]>100 && arr[i]<251)
        {
            bill_2=(1.5*arr[i])+2.3*arr[i];
            printf("\nThe bill paid by %d flat is %d",i+1,bill_2);
        }
        

        else if(arr[i]>250 && arr[i]<601)
        {
            bill_3=(1.5*arr[i])+(2.3*arr[i])+(4.0*arr[i]);
            printf("The bill paid by %d flat is %d",i+1,bill_3);
        }


        

        else
        {
            bill_4=(1.5*arr[i])+(2.3*arr[i])+(4.0*arr[i])+(5.5*arr[i]);
            printf("The bill paid by %d flat is %d",i+1,bill_4);
        }
        
        
        
    }
}

