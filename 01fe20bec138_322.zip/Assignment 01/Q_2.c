#include <stdio.h>
#include<stdlib.h>
#define N 25

void readArray(int arr[N], int n,int a)
{
    int i;

    printf("Enter the elements of array:");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
     
    for (i = 0; i < n; i++)
    {
        if (arr[i] == a)
        {
            printf("Index=%d", i);
        }
        else
        {
            exit(1);
        }
    }
}


    
   


void main()
{
    int arr[N];
    int n,a;
    printf("Enter the size of array:");
    scanf("%d",&n);
    printf("\nEnter the number to be checked:");
    scanf("%d", &a);

    readArray(arr[N],n,a);
    
    checkArray(a);
}
