#include <stdio.h>
#include <stdlib.h>

void readArray(int arr[50], int n);
void displayArray(int arr[50], int n);
void frequency(int arr[50], int n);

void main()
{
    int n, arr[50];
    printf("Enter the number of elements:");
    scanf("%d", &n);

    // n=int m;

    readArray(arr, n);
    displayArray(arr, n);
    frequency(arr, n);
}

void readArray(int arr[50], int n)
{

    int i;
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
}

void displayArray(int arr[50], int n)
{
    int i;
    for (i = 0; i < n; i++)
    {
        printf("%d\t", arr[i]);
        /* code */
    }
}

void frequency(int arr[50], int n)
{
    int i, count_1 = 0, count_2 = 0;
    for (i = 0; i < n; i++)
    {
        if (arr[i] < 0)
        {
            count_1++;
        }
        else
        {
            count_2++;
        }
    }
    printf("The number of elements less than zero are:%d", count_1);
    printf("The number of elements more than zero are:%d", count_2);
}
