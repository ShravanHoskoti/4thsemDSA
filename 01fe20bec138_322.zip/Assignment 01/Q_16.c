#include <stdio.h>
#define N 50

void readArray(int arr[N], int n);
void revArray(int arr[N], int n);
 void display(int rev_arr[N],int n);

void main()
{
    int n, arr[N], rev_arr[N];
    printf("Enter size of array:");
    scanf("%d", &n);
    readArray(arr, n);
    revArray(arr, n);
     display(rev_arr, n);
}

void readArray(int arr[N], int n)
{

    int i;
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
}

void revArray(int arr[N], int n)
{
    int j, i, rev_arr[N];
    for (j = n - 1, i = 0; j >= 0; j--, i++) // n-1  . Ex= size is 11 => 0-10 ; size is 10=>0-9 ...; i.e 0 to n-1
    {
        rev_arr[j] = arr[i];
        
    }


}

void display(int rev_arr[N],int n)
{
    int i;
   for(i=0;i<n;i++)
   {
       printf("%d\t",rev_arr[i]);
   }
   
}


