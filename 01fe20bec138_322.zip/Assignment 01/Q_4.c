// In a class there are 10 students. Course teacher of “DS with Applications ” wants to
//  calculate the class average and also count total number of students who scored above and below class average.
//  Most of the students IQ is very high. Help course teacher to solve the above problem.

#include <stdio.h>
#define N 50

void readArray(int arr[N], int);
void average(int arr[N]);
void main(){
    int arr[N],n;
    printf("Enter the size of the array:");
    scanf("%d",&n);
    readArray(arr,n);
    average(arr);
}





void readArray(int arr[N], int n)
{

    int i;
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
}

// void displayArray(int arr[N], int n)
// {
//     int i;
//     for (i = 0; i < n; i++)
//     {
//         printf("%d\t", arr[i]);
//         /* code */
//     }
// }

void average(int arr[N]){
    int i,below,above,n,sum=0,avg;
    
    for(i=0;i<n;i++){
        sum=sum+arr[i];
    }
    avg=sum/n;
    for ( i = 0; i < n; i++)
    {
        if(arr[i]<avg){
            below++;
        }
        else
        above++;
    }

    printf("The number of students below average is %d",below);
    printf("The number of students above average is %d",above);

    
}
